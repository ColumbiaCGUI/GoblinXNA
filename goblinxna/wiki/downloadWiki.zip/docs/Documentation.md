# Documentation
Please see the installation guide, user manual, and API specification, below. These documents can also be found in the _doc_ directory that comes with the distribution package.

Installation Guide (v4.1): [Installation Guide.pdf](Documentation_Installation Guide.pdf)
User Manual (v4.0): [User Manual.pdf](Documentation_User Manual.pdf)
API Documentation (v4.1): [GoblinXNA.chm.zip](Documentation_GoblinXNA.chm.zip)

# Tutorials
[Calibrating the Camera](Calibrating-the-Camera) (easy method)
[Calibrating the Camera Option 2](Calibrating-the-Camera-Option-2) (more involved)
[Augmented Reality Tutorial](Augmented-Reality-Tutorial) using GoblinXNA and ALVAR
[Creating Custom Markers using ALVAR](Creating-Custom-Markers-using-ALVAR)
[Creating a Custom Marker Layout](Creating-a-Custom-Marker-Layout) (under construction)